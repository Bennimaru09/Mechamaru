class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // app images
  static String imgAsset131 = '$imagePath/img_asset_13_1.png';

  // login images
  static String imgLogin = '$imagePath/img_login.png';

  static String imgSettings = '$imagePath/img_settings.svg';

  // home images
  static String imgRectangle269 = '$imagePath/img_rectangle_269.png';

  static String imgRectangle269214x157 =
      '$imagePath/img_rectangle_269_214x157.png';

  static String imgRectangle2691 = '$imagePath/img_rectangle_269_1.png';

  static String imgStar6 = '$imagePath/img_star_6.svg';

  static String imgAsset101 = '$imagePath/img_asset_10_1.png';

  static String imgAsset111 = '$imagePath/img_asset_11_1.png';

  static String imgAsset121 = '$imagePath/img_asset_12_1.png';

  // home - Tab Container images
  static String imgSettingsPrimary = '$imagePath/img_settings_primary.svg';

  // detail images
  static String imgRectangle275 = '$imagePath/img_rectangle_275.png';

  static String imgRectangle277 = '$imagePath/img_rectangle_277.png';

  static String imgRectangle276 = '$imagePath/img_rectangle_276.png';

  static String imgLinkedin = '$imagePath/img_linkedin.svg';

  static String imgStar638x38 = '$imagePath/img_star_6_38x38.svg';

  static String imgBrightness = '$imagePath/img_brightness.svg';

  static String imgVector44 = '$imagePath/img_vector_44.svg';

  static String imgTelevision = '$imagePath/img_television.svg';

  static String imgVector43 = '$imagePath/img_vector_43.svg';

  static String imgStar639x39 = '$imagePath/img_star_6_39x39.svg';

  static String imgTicket = '$imagePath/img_ticket.svg';

  // Common images
  static String imgArrowLeft = '$imagePath/img_arrow_left.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
