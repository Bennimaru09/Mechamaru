import 'package:aery/core/app_export.dart';
import 'package:flutter/material.dart';

class AppScreen extends StatelessWidget {
  const AppScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: theme.colorScheme.secondaryContainer,
        body: SizedBox(
          width: double.maxFinite,
          child: CustomImageView(
            imagePath: ImageConstant.imgAsset131,
            height: 70.adaptSize,
            width: 70.adaptSize,
            alignment: Alignment.center,
          ),
        ),
      ),
    );
  }
}
