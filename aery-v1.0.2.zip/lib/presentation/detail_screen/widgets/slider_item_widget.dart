import 'package:aery/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class SliderItemWidget extends StatelessWidget {
  const SliderItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: CustomImageView(
        imagePath: ImageConstant.imgRectangle275,
        height: 344.v,
        width: 315.h,
        radius: BorderRadius.circular(
          20.h,
        ),
        margin: EdgeInsets.only(left: 325.h),
      ),
    );
  }
}
