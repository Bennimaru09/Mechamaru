import '../detail_screen/widgets/slider_item_widget.dart';
import 'package:aery/core/app_export.dart';
import 'package:aery/widgets/app_bar/appbar_leading_image.dart';
import 'package:aery/widgets/app_bar/appbar_title.dart';
import 'package:aery/widgets/app_bar/custom_app_bar.dart';
import 'package:aery/widgets/custom_elevated_button.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class DetailScreen extends StatelessWidget {
  DetailScreen({Key? key}) : super(key: key);

  int sliderIndex = 1;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: appTheme.gray300,
            appBar: _buildAppBar(context),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(vertical: 19.v),
                child: Column(children: [
                  _buildSlider(context),
                  SizedBox(height: 33.v),
                  Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                          padding: EdgeInsets.only(left: 29.h),
                          child: RichText(
                              text: TextSpan(children: [
                                TextSpan(
                                    text: "Know the ",
                                    style: CustomTextStyles.titleLargeff2f2f2f),
                                TextSpan(
                                    text: "background",
                                    style: CustomTextStyles.titleLargeff5c7823)
                              ]),
                              textAlign: TextAlign.left))),
                  SizedBox(height: 5.v),
                  Container(
                      width: 315.h,
                      margin: EdgeInsets.symmetric(horizontal: 30.h),
                      child: Text(
                          "Sansevieria, better known as tongue-in-law or snake plant, is a hardy and visually appealing houseplant. It is native to West Africa and is popular around the world as an indoor ornamental plant due to its easy-care nature. Recognized by its unique upright leaves, sansevieria has tall sword leaves with dark green or yellow or white variegated patterns.",
                          maxLines: 7,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.justify,
                          style: theme.textTheme.labelLarge!
                              .copyWith(height: 1.67))),
                  SizedBox(height: 5.v),
                  SizedBox(
                      height: 38.v,
                      width: 161.h,
                      child: Stack(alignment: Alignment.center, children: [
                        Align(
                            alignment: Alignment.centerLeft,
                            child: Container(
                                height: 28.v,
                                width: 68.h,
                                decoration: BoxDecoration(
                                    color: appTheme.gray30002,
                                    borderRadius:
                                        BorderRadius.circular(14.h)))),
                        Align(
                            alignment: Alignment.center,
                            child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  CustomImageView(
                                      imagePath: ImageConstant.imgStar638x38,
                                      height: 38.adaptSize,
                                      width: 38.adaptSize,
                                      radius: BorderRadius.circular(2.h)),
                                  Padding(
                                      padding: EdgeInsets.only(
                                          top: 12.v, bottom: 13.v),
                                      child: Text("3.4",
                                          style: CustomTextStyles
                                              .labelSmallMontserratBlack900)),
                                  CustomElevatedButton(
                                      height: 28.v,
                                      width: 75.h,
                                      text: "60 F",
                                      margin: EdgeInsets.only(
                                          left: 29.h, top: 4.v, bottom: 4.v),
                                      leftIcon: Container(
                                          margin: EdgeInsets.only(right: 11.h),
                                          child: CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgBrightness,
                                              height: 15.adaptSize,
                                              width: 15.adaptSize)),
                                      buttonStyle: CustomButtonStyles.fillGray,
                                      buttonTextStyle: CustomTextStyles
                                          .labelSmallMontserratBlack900)
                                ]))
                      ])),
                  SizedBox(height: 13.v),
                  _buildRow(context),
                  SizedBox(height: 5.v)
                ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 38.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 31.h, top: 18.v, bottom: 23.v),
            onTap: () {
              onTapArrowLeft(context);
            }),
        centerTitle: true,
        title: AppbarTitle(text: "About the plant"));
  }

  /// Section Widget
  Widget _buildSlider(BuildContext context) {
    return CarouselSlider.builder(
        options: CarouselOptions(
            height: 344.v,
            initialPage: 0,
            autoPlay: true,
            viewportFraction: 1.0,
            enableInfiniteScroll: false,
            scrollDirection: Axis.horizontal,
            onPageChanged: (index, reason) {
              sliderIndex = index;
            }),
        itemCount: 5,
        itemBuilder: (context, index, realIndex) {
          return SliderItemWidget();
        });
  }

  /// Section Widget
  Widget _buildRow(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 30.h),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Card(
              clipBehavior: Clip.antiAlias,
              elevation: 0,
              margin: EdgeInsets.all(0),
              color: theme.colorScheme.primary.withOpacity(1),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadiusStyle.roundedBorder10),
              child: Container(
                  height: 49.v,
                  width: 112.h,
                  padding:
                      EdgeInsets.symmetric(horizontal: 46.h, vertical: 14.v),
                  decoration: AppDecoration.outlinePrimary.copyWith(
                      borderRadius: BorderRadiusStyle.roundedBorder10),
                  child: Stack(alignment: Alignment.centerLeft, children: [
                    CustomImageView(
                        imagePath: ImageConstant.imgVector44,
                        height: 8.v,
                        width: 18.h,
                        alignment: Alignment.topLeft,
                        margin: EdgeInsets.only(top: 1.v)),
                    Align(
                        alignment: Alignment.centerLeft,
                        child: SizedBox(
                            height: 20.v,
                            width: 19.h,
                            child: Stack(
                                alignment: Alignment.bottomLeft,
                                children: [
                                  CustomImageView(
                                      imagePath: ImageConstant.imgTelevision,
                                      height: 20.v,
                                      width: 19.h,
                                      alignment: Alignment.center),
                                  CustomImageView(
                                      imagePath: ImageConstant.imgVector43,
                                      height: 7.v,
                                      width: 11.h,
                                      alignment: Alignment.bottomLeft,
                                      margin: EdgeInsets.only(left: 3.h))
                                ])))
                  ]))),
          Container(
              margin: EdgeInsets.only(left: 10.h),
              padding: EdgeInsets.symmetric(horizontal: 12.h, vertical: 1.v),
              decoration: AppDecoration.outlinePrimary1
                  .copyWith(borderRadius: BorderRadiusStyle.roundedBorder10),
              child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(height: 2.v),
                    CustomImageView(
                        imagePath: ImageConstant.imgStar639x39,
                        height: 39.adaptSize,
                        width: 39.adaptSize,
                        radius: BorderRadius.circular(3.h))
                  ])),
          Card(
              clipBehavior: Clip.antiAlias,
              elevation: 0,
              margin: EdgeInsets.only(left: 11.h),
              color: theme.colorScheme.primary.withOpacity(1),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadiusStyle.roundedBorder10),
              child: Container(
                  height: 49.v,
                  width: 112.h,
                  padding:
                      EdgeInsets.symmetric(horizontal: 47.h, vertical: 15.v),
                  decoration: AppDecoration.outlinePrimary.copyWith(
                      borderRadius: BorderRadiusStyle.roundedBorder10),
                  child: Stack(alignment: Alignment.topCenter, children: [
                    CustomImageView(
                        imagePath: ImageConstant.imgTicket,
                        height: 18.adaptSize,
                        width: 18.adaptSize,
                        alignment: Alignment.bottomCenter),
                    CustomImageView(
                        imagePath: ImageConstant.imgVector43,
                        height: 12.v,
                        width: 9.h,
                        alignment: Alignment.topCenter,
                        margin: EdgeInsets.only(top: 2.v))
                  ])))
        ]));
  }

  /// Navigates back to the previous screen.
  onTapArrowLeft(BuildContext context) {
    Navigator.pop(context);
  }
}
