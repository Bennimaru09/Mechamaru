import 'package:aery/core/app_export.dart';
import 'package:aery/presentation/home_page/home_page.dart';
import 'package:aery/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

class HomeTabContainerScreen extends StatefulWidget {
  const HomeTabContainerScreen({Key? key})
      : super(
          key: key,
        );

  @override
  HomeTabContainerScreenState createState() => HomeTabContainerScreenState();
}

class HomeTabContainerScreenState extends State<HomeTabContainerScreen>
    with TickerProviderStateMixin {
  late TabController tabviewController;

  @override
  void initState() {
    super.initState();
    tabviewController = TabController(length: 4, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              SizedBox(height: 47.v),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildFindYourPlantRow(context),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Padding(
                          padding: EdgeInsets.only(left: 30.h),
                          child: Text(
                            "les’t start planting",
                            style: CustomTextStyles.titleLargeBlack900,
                          ),
                        ),
                      ),
                      SizedBox(height: 19.v),
                      _buildTabview(context),
                      SizedBox(
                        height: 612.v,
                        child: TabBarView(
                          controller: tabviewController,
                          children: [
                            HomePage(),
                            HomePage(),
                            HomePage(),
                            HomePage(),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildFindYourPlantRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 30.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 172.h,
            child: RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: "find your\n",
                    style: CustomTextStyles.displaySmallff000000,
                  ),
                  TextSpan(
                    text: "plant",
                    style: CustomTextStyles.displaySmallff5c7823,
                  ),
                ],
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 119.h,
              top: 15.v,
              bottom: 45.v,
            ),
            child: CustomIconButton(
              height: 24.adaptSize,
              width: 24.adaptSize,
              padding: EdgeInsets.all(2.h),
              child: CustomImageView(
                imagePath: ImageConstant.imgSettingsPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildTabview(BuildContext context) {
    return Container(
      height: 23.v,
      width: 305.h,
      child: TabBar(
        controller: tabviewController,
        labelPadding: EdgeInsets.zero,
        labelColor: theme.colorScheme.onPrimaryContainer,
        labelStyle: TextStyle(
          fontSize: 14.fSize,
          fontFamily: 'Raleway',
          fontWeight: FontWeight.w500,
        ),
        unselectedLabelColor: appTheme.gray40001,
        unselectedLabelStyle: TextStyle(
          fontSize: 14.fSize,
          fontFamily: 'Raleway',
          fontWeight: FontWeight.w500,
        ),
        indicator: BoxDecoration(
          borderRadius: BorderRadius.circular(
            11.h,
          ),
          border: Border.all(
            color: theme.colorScheme.onPrimaryContainer,
            width: 1.h,
          ),
        ),
        tabs: [
          Tab(
            child: Text(
              "All",
            ),
          ),
          Tab(
            child: Text(
              "Plant",
            ),
          ),
          Tab(
            child: Text(
              "Vegetable",
            ),
          ),
          Tab(
            child: Text(
              "Fruit",
            ),
          ),
        ],
      ),
    );
  }
}
