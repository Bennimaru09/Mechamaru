import 'package:aery/core/app_export.dart';
import 'package:flutter/material.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        extendBody: true,
        extendBodyBehindAppBar: true,
        body: Container(
          width: SizeUtils.width,
          height: SizeUtils.height,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(
                ImageConstant.imgLogin,
              ),
              fit: BoxFit.cover,
            ),
          ),
          child: Container(
            width: double.maxFinite,
            padding: EdgeInsets.symmetric(
              horizontal: 44.h,
              vertical: 80.v,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Spacer(
                  flex: 42,
                ),
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 109.h),
                  padding: EdgeInsets.symmetric(
                    horizontal: 6.h,
                    vertical: 8.v,
                  ),
                  decoration: AppDecoration.gradientGrayToBlueGray.copyWith(
                    borderRadius: BorderRadiusStyle.roundedBorder33,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        margin: EdgeInsets.only(right: 1.h),
                        padding: EdgeInsets.symmetric(
                          horizontal: 17.h,
                          vertical: 18.v,
                        ),
                        decoration: AppDecoration.fillOnPrimary.copyWith(
                          borderRadius: BorderRadiusStyle.circleBorder27,
                        ),
                        child: Text(
                          "GO",
                          style:
                              CustomTextStyles.labelLargeMontserratBluegray900,
                        ),
                      ),
                      SizedBox(height: 8.v),
                      SizedBox(
                        height: 32.v,
                        width: 16.h,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            CustomImageView(
                              imagePath: ImageConstant.imgSettings,
                              height: 16.adaptSize,
                              width: 16.adaptSize,
                              alignment: Alignment.topCenter,
                            ),
                            CustomImageView(
                              imagePath: ImageConstant.imgSettings,
                              height: 16.adaptSize,
                              width: 16.adaptSize,
                              alignment: Alignment.center,
                            ),
                            CustomImageView(
                              imagePath: ImageConstant.imgSettings,
                              height: 16.adaptSize,
                              width: 16.adaptSize,
                              alignment: Alignment.bottomCenter,
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 30.v),
                    ],
                  ),
                ),
                Spacer(
                  flex: 57,
                ),
                Text(
                  "AERY",
                  style: theme.textTheme.displayMedium,
                ),
                SizedBox(height: 3.v),
                SizedBox(
                  width: 286.h,
                  child: Text(
                    "is here to ease your plant's journey. Welcome, green thumbs! Let's take care of our garden together",
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                    style: CustomTextStyles.bodyMediumOnPrimary.copyWith(
                      height: 1.23,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
