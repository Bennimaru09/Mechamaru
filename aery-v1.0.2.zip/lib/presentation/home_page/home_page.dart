import '../home_page/widgets/thirtyone_item_widget.dart';
import '../home_page/widgets/userprofilelist1_item_widget.dart';
import '../home_page/widgets/userprofilelist_item_widget.dart';
import 'package:aery/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class HomePage extends StatefulWidget {
  const HomePage({Key? key})
      : super(
          key: key,
        );

  @override
  HomePageState createState() => HomePageState();
}

class HomePageState extends State<HomePage>
    with AutomaticKeepAliveClientMixin<HomePage> {
  @override
  bool get wantKeepAlive => true;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: SizeUtils.width,
          child: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(height: 19.v),
                Align(
                  alignment: Alignment.bottomRight,
                  child: Padding(
                    padding: EdgeInsets.only(left: 30.h),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildUserProfileList(context),
                        SizedBox(height: 30.v),
                        _buildFortyTwoStack(context),
                        SizedBox(height: 33.v),
                        Text(
                          "Popular ",
                          style: theme.textTheme.titleLarge,
                        ),
                        SizedBox(height: 29.v),
                        _buildUserProfileList1(context),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildUserProfileList(BuildContext context) {
    return SizedBox(
      height: 214.v,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        separatorBuilder: (
          context,
          index,
        ) {
          return SizedBox(
            width: 10.h,
          );
        },
        itemCount: 3,
        itemBuilder: (context, index) {
          return UserprofilelistItemWidget();
        },
      ),
    );
  }

  /// Section Widget
  Widget _buildFortyTwoStack(BuildContext context) {
    return SizedBox(
      height: 217.v,
      width: 345.h,
      child: Stack(
        alignment: Alignment.topLeft,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgAsset101,
            height: 154.v,
            width: 118.h,
            alignment: Alignment.topLeft,
            margin: EdgeInsets.only(top: 24.v),
          ),
          Align(
            alignment: Alignment.topLeft,
            child: Text(
              "My plant",
              style: theme.textTheme.titleLarge,
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgAsset111,
            height: 170.v,
            width: 146.h,
            alignment: Alignment.topRight,
            margin: EdgeInsets.only(
              top: 10.v,
              right: 55.h,
            ),
          ),
          Align(
            alignment: Alignment.bottomRight,
            child: SizedBox(
              height: 217.v,
              child: ListView.separated(
                padding: EdgeInsets.only(
                  left: 18.h,
                  top: 53.v,
                ),
                scrollDirection: Axis.horizontal,
                separatorBuilder: (
                  context,
                  index,
                ) {
                  return SizedBox(
                    width: 73.h,
                  );
                },
                itemCount: 3,
                itemBuilder: (context, index) {
                  return ThirtyoneItemWidget();
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildUserProfileList1(BuildContext context) {
    return SizedBox(
      height: 214.v,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        separatorBuilder: (
          context,
          index,
        ) {
          return SizedBox(
            width: 10.h,
          );
        },
        itemCount: 3,
        itemBuilder: (context, index) {
          return Userprofilelist1ItemWidget();
        },
      ),
    );
  }
}
