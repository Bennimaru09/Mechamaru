import 'package:aery/core/app_export.dart';
import 'package:aery/widgets/custom_elevated_button.dart';
import 'package:aery/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class UserprofilelistItemWidget extends StatelessWidget {
  const UserprofilelistItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 214.v,
      width: 157.h,
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgRectangle269,
            height: 214.v,
            width: 157.h,
            radius: BorderRadius.circular(
              20.h,
            ),
            alignment: Alignment.center,
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: EdgeInsets.fromLTRB(15.h, 177.v, 15.h, 14.v),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CustomElevatedButton(
                    width: 57.h,
                    text: "Try plant",
                  ),
                  CustomIconButton(
                    height: 21.adaptSize,
                    width: 21.adaptSize,
                    child: CustomImageView(),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
