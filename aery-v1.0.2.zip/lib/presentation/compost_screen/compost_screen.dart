import 'package:aery/core/app_export.dart';
import 'package:aery/widgets/app_bar/appbar_leading_image.dart';
import 'package:aery/widgets/app_bar/appbar_title.dart';
import 'package:aery/widgets/app_bar/custom_app_bar.dart';
import 'package:aery/widgets/custom_outlined_button.dart';
import 'package:flutter/material.dart';

class CompostScreen extends StatelessWidget {
  const CompostScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: appTheme.gray300,
            appBar: _buildAppBar(context),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 28.h),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                          width: 172.h,
                          margin: EdgeInsets.only(left: 2.h),
                          child: Text("Compost\ndepth",
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: theme.textTheme.displaySmall)),
                      SizedBox(height: 4.v),
                      Padding(
                          padding: EdgeInsets.only(left: 2.h),
                          child: Text(
                              "les’t start with you’re compost depth in CM",
                              style: theme.textTheme.bodyMedium)),
                      SizedBox(height: 26.v),
                      _buildCompostColumn(context),
                      SizedBox(height: 29.v),
                      Padding(
                          padding: EdgeInsets.only(left: 2.h),
                          child: Text("Pot size",
                              style: CustomTextStyles.displaySmallPrimary)),
                      SizedBox(height: 7.v),
                      Padding(
                          padding: EdgeInsets.only(left: 2.h),
                          child: Text("les’t start with you’re pot size in CM",
                              style: theme.textTheme.bodyMedium)),
                      SizedBox(height: 15.v),
                      _buildCompostRow(context),
                      SizedBox(height: 5.v)
                    ])),
            bottomNavigationBar: _buildBuyCompostButton(context)));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 37.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 30.h, top: 18.v, bottom: 23.v),
            onTap: () {
              onTapArrowLeft(context);
            }),
        centerTitle: true,
        title: AppbarTitle(text: "Compost Calculator"));
  }

  /// Section Widget
  Widget _buildCompostColumn(BuildContext context) {
    return Container(
        width: 315.h,
        margin: EdgeInsets.only(right: 4.h),
        padding: EdgeInsets.symmetric(horizontal: 121.h, vertical: 17.v),
        decoration: AppDecoration.outlineBlack900
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder20),
        child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                  padding: EdgeInsets.only(left: 16.h),
                  child: Text("24", style: theme.textTheme.titleMedium)),
              SizedBox(height: 3.v),
              Divider(endIndent: 19.h),
              SizedBox(height: 2.v),
              Padding(
                  padding: EdgeInsets.only(left: 8.h),
                  child: Text("25", style: theme.textTheme.headlineLarge)),
              SizedBox(height: 1.v),
              Divider(endIndent: 19.h),
              SizedBox(height: 4.v),
              Padding(
                  padding: EdgeInsets.only(left: 15.h),
                  child: Text("26", style: theme.textTheme.titleMedium)),
              SizedBox(height: 4.v)
            ]));
  }

  /// Section Widget
  Widget _buildCompostRow(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 2.h),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Padding(
              padding: EdgeInsets.only(right: 5.h),
              child: _buildPotSizeColumn(context,
                  dynamicText1: "24", dynamicText2: "25", dynamicText3: "26")),
          Padding(
              padding: EdgeInsets.only(left: 5.h),
              child: _buildPotSizeColumn(context,
                  dynamicText1: "24", dynamicText2: "25", dynamicText3: "26"))
        ]));
  }

  /// Section Widget
  Widget _buildBuyCompostButton(BuildContext context) {
    return CustomOutlinedButton(
        text: "Buy Compost",
        margin: EdgeInsets.only(left: 30.h, right: 32.h, bottom: 36.v));
  }

  /// Common widget
  Widget _buildPotSizeColumn(
    BuildContext context, {
    required String dynamicText1,
    required String dynamicText2,
    required String dynamicText3,
  }) {
    return Expanded(
        child: SizedBox(
            width: double.maxFinite,
            child: Container(
                padding: EdgeInsets.symmetric(horizontal: 49.h, vertical: 45.v),
                decoration: AppDecoration.fillPrimary
                    .copyWith(borderRadius: BorderRadiusStyle.roundedBorder20),
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(height: 4.v),
                      Text(dynamicText1,
                          style: theme.textTheme.titleMedium!
                              .copyWith(color: theme.colorScheme.onPrimary)),
                      SizedBox(height: 3.v),
                      SizedBox(width: 53.h, child: Divider()),
                      SizedBox(height: 2.v),
                      Text(dynamicText2,
                          style: theme.textTheme.headlineLarge!
                              .copyWith(color: appTheme.gray300)),
                      SizedBox(height: 1.v),
                      SizedBox(width: 53.h, child: Divider()),
                      SizedBox(height: 4.v),
                      Text(dynamicText3,
                          style: theme.textTheme.titleMedium!
                              .copyWith(color: theme.colorScheme.onPrimary))
                    ]))));
  }

  /// Navigates back to the previous screen.
  onTapArrowLeft(BuildContext context) {
    Navigator.pop(context);
  }
}
