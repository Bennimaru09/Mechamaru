import 'package:flutter/material.dart';
import 'package:aery/presentation/app_screen/app_screen.dart';
import 'package:aery/presentation/login_screen/login_screen.dart';
import 'package:aery/presentation/home_tab_container_screen/home_tab_container_screen.dart';
import 'package:aery/presentation/detail_screen/detail_screen.dart';
import 'package:aery/presentation/compost_screen/compost_screen.dart';
import 'package:aery/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String appScreen = '/app_screen';

  static const String loginScreen = '/login_screen';

  static const String homePage = '/home_page';

  static const String homeTabContainerScreen = '/home_tab_container_screen';

  static const String detailScreen = '/detail_screen';

  static const String compostScreen = '/compost_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    appScreen: (context) => AppScreen(),
    loginScreen: (context) => LoginScreen(),
    homeTabContainerScreen: (context) => HomeTabContainerScreen(),
    detailScreen: (context) => DetailScreen(),
    compostScreen: (context) => CompostScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
