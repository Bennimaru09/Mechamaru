import 'package:flutter/material.dart';
import '../core/app_export.dart';

/// A collection of pre-defined text styles for customizing text appearance,
/// categorized by different font families and weights.
/// Additionally, this class includes extensions on [TextStyle] to easily apply specific font families to text.

class CustomTextStyles {
  // Body text style
  static get bodyMediumOnPrimary => theme.textTheme.bodyMedium!.copyWith(
        color: theme.colorScheme.onPrimary.withOpacity(1),
      );
  // Display text style
  static get displaySmallPrimary => theme.textTheme.displaySmall!.copyWith(
        color: theme.colorScheme.primary.withOpacity(1),
      );
  static get displaySmallff000000 => theme.textTheme.displaySmall!.copyWith(
        color: Color(0XFF000000),
      );
  static get displaySmallff5c7823 => theme.textTheme.displaySmall!.copyWith(
        color: Color(0XFF5C7823),
      );
  // Label text style
  static get labelLargeGray300 => theme.textTheme.labelLarge!.copyWith(
        color: appTheme.gray300,
      );
  static get labelLargeMontserratBluegray900 =>
      theme.textTheme.labelLarge!.montserrat.copyWith(
        color: appTheme.blueGray900,
        fontWeight: FontWeight.w700,
      );
  static get labelSmallMontserratBlack900 =>
      theme.textTheme.labelSmall!.montserrat.copyWith(
        color: appTheme.black900,
        fontSize: 9.fSize,
        fontWeight: FontWeight.w700,
      );
  // Title text style
  static get titleLargeBlack900 => theme.textTheme.titleLarge!.copyWith(
        color: appTheme.black900,
        fontWeight: FontWeight.w200,
      );
  static get titleLargeGray300 => theme.textTheme.titleLarge!.copyWith(
        color: appTheme.gray300,
      );
  static get titleLargeMontserratPrimary =>
      theme.textTheme.titleLarge!.montserrat.copyWith(
        color: theme.colorScheme.primary.withOpacity(1),
      );
  static get titleLargeff2f2f2f => theme.textTheme.titleLarge!.copyWith(
        color: Color(0XFF2F2F2F),
      );
  static get titleLargeff5c7823 => theme.textTheme.titleLarge!.copyWith(
        color: Color(0XFF5C7823),
      );
  static get titleSmallMontserratPrimary =>
      theme.textTheme.titleSmall!.montserrat.copyWith(
        color: theme.colorScheme.primary.withOpacity(1),
        fontWeight: FontWeight.w800,
      );
  static get titleSmallOnPrimaryContainer =>
      theme.textTheme.titleSmall!.copyWith(
        color: theme.colorScheme.onPrimaryContainer,
      );
}

extension on TextStyle {
  TextStyle get alexandria {
    return copyWith(
      fontFamily: 'Alexandria',
    );
  }

  TextStyle get raleway {
    return copyWith(
      fontFamily: 'Raleway',
    );
  }

  TextStyle get montserrat {
    return copyWith(
      fontFamily: 'Montserrat',
    );
  }
}
